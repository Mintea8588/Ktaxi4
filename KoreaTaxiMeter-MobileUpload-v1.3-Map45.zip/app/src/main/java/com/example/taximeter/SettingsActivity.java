package com.example.taximeter;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;

public class SettingsActivity extends Activity {
    TariffConfig c; EditText base,baseM,df,dm,tf,ts,low,np,op,ns,ne; Switch night,out;
    EditText e(String label,String v,LinearLayout p, boolean decimal){
        TextView l=new TextView(this); l.setText(label); l.setTextSize(15); l.setPadding(0,14,0,4); p.addView(l);
        EditText x=new EditText(this); x.setText(v); x.setTextSize(17); x.setSingleLine(true);
        x.setInputType(decimal ? InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL : InputType.TYPE_CLASS_NUMBER);
        p.addView(x); return x;
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); c=new TariffConfig(this);
        ScrollView sv=new ScrollView(this); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(28,24,28,30); sv.addView(p);
        TextView h=new TextView(this); h.setText("요금 체계 커스터마이징"); h.setTextSize(25); h.setGravity(Gravity.CENTER_VERTICAL); p.addView(h);
        TextView info=new TextView(this); info.setText("기본요금에는 아래의 '기본거리'가 포함됩니다. 기본거리 이후부터 거리요금이 붙습니다."); info.setPadding(0,8,0,16); p.addView(info);
        base=e("기본요금 (원)",""+c.baseFare(),p,false);
        baseM=e("기본요금 포함거리 (m)",""+c.baseDistanceM(),p,false);
        df=e("거리 단위요금 (원)",""+c.distanceUnitFare(),p,false);
        dm=e("거리 단위 (m)",""+c.distanceUnitM(),p,false);
        tf=e("저속 시간 단위요금 (원)",""+c.timeUnitFare(),p,false);
        ts=e("저속 시간 단위 (초)",""+c.timeUnitSec(),p,false);
        low=e("시간요금 전환 기준속도 (km/h)",""+c.lowSpeedKmh(),p,true);
        np=e("심야 할증 (%)",""+c.nightPct(),p,false);
        op=e("시계외 할증 (%)",""+c.outPct(),p,false);
        ns=e("심야 시작 (HH:mm)",c.nightStart(),p,false); ns.setInputType(InputType.TYPE_CLASS_DATETIME|InputType.TYPE_DATETIME_VARIATION_TIME);
        ne=e("심야 종료 (HH:mm)",c.nightEnd(),p,false); ne.setInputType(InputType.TYPE_CLASS_DATETIME|InputType.TYPE_DATETIME_VARIATION_TIME);
        night=new Switch(this); night.setText("심야할증 자동 적용"); night.setChecked(c.autoNight()); p.addView(night);
        out=new Switch(this); out.setText("시계외할증 적용"); out.setChecked(c.outOfArea()); p.addView(out);
        Button save=new Button(this); save.setText("저장"); p.addView(save);
        save.setOnClickListener(v->{
            try{
                c.save(Integer.parseInt(base.getText().toString()),Integer.parseInt(baseM.getText().toString()),Integer.parseInt(df.getText().toString()),Integer.parseInt(dm.getText().toString()),Integer.parseInt(tf.getText().toString()),Integer.parseInt(ts.getText().toString()),Float.parseFloat(low.getText().toString()),Integer.parseInt(np.getText().toString()),Integer.parseInt(op.getText().toString()),ns.getText().toString(),ne.getText().toString(),night.isChecked());
                c.setOutOfArea(out.isChecked()); Toast.makeText(this,"저장되었습니다",Toast.LENGTH_SHORT).show(); finish();
            }catch(Exception ex){Toast.makeText(this,"숫자/시간 형식을 확인하세요",Toast.LENGTH_SHORT).show();}
        });
        setContentView(sv);
    }
}
